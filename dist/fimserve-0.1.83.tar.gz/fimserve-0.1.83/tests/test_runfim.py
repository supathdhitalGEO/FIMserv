import os
import fimserve as fm

huc = "03020202"

# run the FIM model
fm.runOWPHANDFIM(huc)
