Installation guide
====================================
It contains the installation guide for the FIMserv framework in local, cloud as well as for the workfolows using poetry.