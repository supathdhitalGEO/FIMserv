Detailed functionality
====================================
It contains each functionality of the FIMserv framework in detail.